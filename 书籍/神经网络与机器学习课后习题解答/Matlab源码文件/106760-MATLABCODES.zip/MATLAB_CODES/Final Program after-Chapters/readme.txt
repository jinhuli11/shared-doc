/* Author: Yanbo Xue
 * Cognitive Systems Laboratory
 * http://soma.mcmaster.ca
 * Email: yxue@grads.ece.mcmaster.ca
 */

run main.m to generate figures for after-chapter problems